# Fullstack SaaS Application (Internship Project)

This is a lightweight, ready-to-push scaffold for your **Full Stack Integration & Databases** internship task.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: PostgreSQL (via Docker)
- Deployment: Docker Compose + Cloud Ready

## How to Run
1. Extract this folder.
2. Open a terminal and run:
```bash
docker-compose up --build
```
3. Visit:
   - Frontend → http://localhost:3000
   - Backend → http://localhost:4000/api/health

## GitHub Upload
```bash
git init
git add .
git commit -m "Initial Fullstack SaaS Project"
git branch -M main
git remote add origin git@github.com:<your-username>/fullstack-saas.git
git push -u origin main
```
