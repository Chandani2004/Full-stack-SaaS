import {PricingTable} from "@clerk/nextjs";

const Subscription = () => {
    return (
        <main>
            <PricingTable />
        </main>
    )
}
export default Subscription
